<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.

// -----------------------------------------
// Custom Widgets                    -
// -----------------------------------------
function mount_resort_custom_widgets() {
  $custom_widgets = array();
  
  $widgets = cs_get_option( 'widgetarea-custom' );
  $widgets = is_array( $widgets ) ? $widgets : array();

  $widgets = array_filter($widgets);

  if( isset( $widgets ) ):
    foreach ( $widgets as $widget ) :
      $id = mb_convert_case($widget['widgetarea-custom-name'], MB_CASE_LOWER, "UTF-8");
      $id = str_replace(" ", "-", $id);
      $custom_widgets[$id] = $widget['widgetarea-custom-name'];
    endforeach;
  endif;

  return $custom_widgets;  
}

// -----------------------------------------
// Layer Sliders
// -----------------------------------------
function mount_resort_layersliders() {
  $layerslider = array(  esc_html__('Select a slider','mountresort') );

  if( mount_resort_is_plugin_active('LayerSlider/layerslider.php') ) {

    $sliders = LS_Sliders::find(array('limit' => 50));

    if(!empty($sliders)) {
      foreach($sliders as $key => $item){
        $layerslider[ $item['id'] ] = $item['name'];
      }
    }
  }

  return $layerslider;
}

// -----------------------------------------
// Revolution Sliders
// -----------------------------------------
function mount_resort_revolutionsliders() {
  $revolutionslider = array( '' => esc_html__('Select a slider','mountresort') );

  if(mount_resort_is_plugin_active('revslider/revslider.php')) {
    $sld = new RevSlider();
    $sliders = $sld->getArrSliders();
    if(!empty($sliders)){
      foreach($sliders as $key => $item) {
        $revolutionslider[$item->getAlias()] = $item->getTitle();
      }
    }    
  }

  return $revolutionslider;  
}

// -----------------------------------------
// Meta Layout Section
// -----------------------------------------
$meta_layout_section =array(
  'name'  => 'layout_section',
  'title' => esc_html__('Layout', 'mountresort'),
  'icon'  => 'fa fa-columns',
  'fields' =>  array(
    array(
      'id'  => 'layout',
      'type' => 'image_select',
      'title' => esc_html__('Page Layout', 'mountresort' ),
      'options'      => array(
          'content-full-width'   => MOUNT_RESORT_THEME_URI . '/cs-framework-override/images/without-sidebar.png',
          'with-left-sidebar'    => MOUNT_RESORT_THEME_URI . '/cs-framework-override/images/left-sidebar.png',
          'with-right-sidebar'   => MOUNT_RESORT_THEME_URI . '/cs-framework-override/images/right-sidebar.png',
          'with-both-sidebar'    => MOUNT_RESORT_THEME_URI . '/cs-framework-override/images/both-sidebar.png',
          'fullwidth'            => MOUNT_RESORT_THEME_URI . '/cs-framework-override/images/fullwidth.png',
      ),
      'default'      => 'content-full-width',
    
      'attributes'   => array( 'data-depend-id' => 'page-layout' )
    ),
    array(
      'id'        => 'show-standard-sidebar-left',
      'type'      => 'switcher',
      'title'     => esc_html__('Show Standard Left Sidebar', 'mountresort' ),
      'dependency'  => array( 'page-layout', 'any', 'with-left-sidebar,with-both-sidebar' ),
    ),
    array(
      'id'        => 'widget-area-left',
      'type'      => 'select',
      'title'     => esc_html__('Choose Left Widget Areas', 'mountresort' ),
      'class'     => 'chosen',
      'options'   => mount_resort_custom_widgets(),
      'attributes'  => array( 
        'multiple'  => 'multiple',
        'data-placeholder' => esc_html__('Select Left Widget Areas','mountresort'),
        'style' => 'width: 400px;'
      ),
      'dependency'  => array( 'page-layout', 'any', 'with-left-sidebar,with-both-sidebar' ),
    ),
    array(
      'id'          => 'show-standard-sidebar-right',
      'type'        => 'switcher',
      'title'       => esc_html__('Show Standard Right Sidebar', 'mountresort' ),
      'dependency'  => array( 'page-layout', 'any', 'with-right-sidebar,with-both-sidebar' ),
    ),
    array(
      'id'        => 'widget-area-right',
      'type'      => 'select',
      'title'     => esc_html__('Choose Right Widget Areas', 'mountresort' ),
      'class'     => 'chosen',
      'options'   => mount_resort_custom_widgets(),
      'attributes'    => array( 
        'multiple' => 'multiple',
        'data-placeholder' => esc_html__('Select Right Widget Areas','mountresort'),
        'style' => 'width: 400px;'
      ),
      'dependency'  => array( 'page-layout', 'any', 'with-right-sidebar,with-both-sidebar' ),
    )
  )
);

// -----------------------------------------
// Meta Breadcrumb Section
// -----------------------------------------
$meta_breadcrumb_section = array(
  'name'  => 'breadcrumb_section',
  'title' => esc_html__('Breadcrumb', 'mountresort'),
  'icon'  => 'fa fa-arrows-h',
  'fields' =>  array(
    array(
      'id'      => 'show-breadcrumb',
      'type'    => 'switcher',
      'title'   => esc_html__('Show Breadcrumb', 'mountresort' ),
      'default' => true
    ),
    array(
      'id'    => 'breadcrumb_background',
      'type'  => 'background',
      'title' => esc_html__('Background', 'mountresort' ),
      'dependency'   => array( 'show-breadcrumb', '==', 'true' ),
    ),
  )
);

// -----------------------------------------
// Meta Slider Section
// -----------------------------------------
$meta_slider_section = array(
  'name'  => 'slider_section',
  'title' => esc_html__('Slider', 'mountresort'),
  'icon'  => 'fa fa-slideshare',
  'fields' =>  array(
    array(
      'id'           => 'slider-notice',
      'type'         => 'notice',
      'class'        => 'danger',
      'content'      => __('Slider tab works only if breadcrumb disabled.','mountresort'),
      'class'        => 'margin-30 cs-danger',
      'dependency'   => array( 'show-breadcrumb', '==', 'true' ),
    ),

    array(
      'id'           => 'show-slider',
      'type'         => 'switcher',
      'title'        => esc_html__('Show Slider', 'mountresort' ),
      'dependency'   => array( 'show-breadcrumb', '==', 'false' ),
    ),

    array(
      'id'                 => 'slider-type',
      'type'               => 'select',
      'title'              => esc_html__('Slider', 'mountresort' ),
      'options'            => array(
        ''                 => esc_html__('Select a slider','mountresort'),
        'layerslider'      => esc_html__('Layer slider','mountresort'),
        'revolutionslider' => esc_html__('Revolution slider','mountresort'),
        'customslider'     => esc_html__('Custom Slider Shortcode','mountresort'),
      ),
      'validate' => 'required',
      'dependency'         => array( 'show-breadcrumb|show-slider', '==|==', 'false|true' ),
    ),

    array(
      'id'          => 'layerslider',
      'type'        => 'select',
      'title'       => esc_html__('Layer Slider', 'mountresort' ),
      'options'     => mount_resort_layersliders(),
      'validate'    => 'required',
      'dependency'  => array( 'show-breadcrumb|show-slider|slider-type', '==|==|==', 'false|true|layerslider' )
    ),

    array(
      'id'          => 'revolutionslider',
      'type'        => 'select',
      'title'       => esc_html__('Revolution Slider', 'mountresort' ),
      'options'     => mount_resort_revolutionsliders(),
      'validate'    => 'required',
      'dependency'  => array( 'show-breadcrumb|show-slider|slider-type', '==|==|==', 'false|true|revolutionslider' )
    ),

    array(
      'id'          => 'customslider',
      'type'        => 'textarea',
      'title'       => esc_html__('Custom Slider Code', 'mountresort' ),
      'validate'    => 'required',
      'dependency'  => array( 'show-breadcrumb|show-slider|slider-type', '==|==|==', 'false|true|customslider' )
    ),    
  )  
);

// -----------------------------------------
// Blog Template Section
// -----------------------------------------
$blog_template_section = array(
  'name'  => 'blog_template_section',
  'title' => esc_html__('Blog Template', 'mountresort'),
  'icon'  => 'fa fa-files-o',
  'fields' =>  array(
    array(
      'id'           => 'blog-tpl-notice',
      'type'         => 'notice',
      'class'        => 'success',
      'content'      => __('Blog Tab Works only if page template set to Blog Template in Page Attributes','mountresort'),
      'class'        => 'margin-30 cs-success',      
    ),
    array(
      'id'                     => 'blog-post-layout',
      'type'                   => 'image_select',
      'title'                  => esc_html__('Post Layout', 'mountresort' ),
      'options'                => array(
          'one-column'         => MOUNT_RESORT_THEME_URI . '/cs-framework-override/images/one-column.png',
          'one-half-column'    => MOUNT_RESORT_THEME_URI . '/cs-framework-override/images/one-half-column.png',
          'one-third-column'   => MOUNT_RESORT_THEME_URI . '/cs-framework-override/images/one-third-column.png',
      ),
      'default'                => 'one-half-column'
    ),
    array(
      'id'                     => 'blog-post-style',
      'type'                   => 'select',
      'title'                  => esc_html__('Post Style', 'mountresort' ),
      'options'                => array(
        'default' => esc_html__('Default','mountresort'),
        'entry-date-left' => esc_html__('Date Left','mountresort'),
        'entry-date-author-left' => esc_html__('Date and Author Left','mountresort'),
        'blog-medium-style' => esc_html__('Medium','mountresort'),
        'blog-medium-style dt-blog-medium-highlight' => esc_html__('Medium Highlight','mountresort'),
        'blog-medium-style dt-blog-medium-highlight dt-sc-skin-highlight' => esc_html__('Medium Skin Highlight','mountresort')
      ),
    ),
    array(
      'id'      => 'enable-blog-readmore',
      'type'    => 'switcher',
      'title'   => esc_html__('Read More', 'mountresort' ),
      'default' => true
    ),
    array(
      'id'           => 'blog-readmore',
      'type'         => 'textarea',
      'title'        => esc_html__('Read More Shortcode', 'mountresort' ),
      'default'      => '[dt_sc_button title="Read More" style="filled" icon_type="fontawesome" iconalign="icon-right with-icon" iconclass="fa fa-long-arrow-right" class="type1" /]',
      'dependency'   => array( 'enable-blog-readmore', '==', 'true' ),
    ),
    array(
      'id'      => 'blog-post-excerpt',
      'type'    => 'switcher',
      'title'   => esc_html__('Allow Excerpt', 'mountresort' ),
      'default' => true
    ),
    array(
      'id'           => 'blog-post-excerpt-length',
      'type'         => 'number',
      'title'        => esc_html__('Excerpt Length', 'mountresort' ),
      'default'      => '45',
      'dependency'   => array( 'blog-post-excerpt', '==', 'true' ),
    ),
    array(
      'id'           => 'blog-post-per-page',
      'type'         => 'number',
      'title'        => esc_html__('Post Per Page', 'mountresort' ),
      'default'      => '-1',      
    ),
    array(
      'id'             => 'blog-post-cats',
      'type'           => 'select',
      'title'          => esc_html__('Categories','mountresort'),
      'options'        => 'categories',
      'default_option' => esc_html__('Select a categories','mountresort'),
      'class'              => 'chosen',
      'attributes'         => array(
        'multiple'         => 'only-key',
        'style'            => 'width: 200px;'
      ),
      'info'           => esc_html__('Select categories to exclude from your blog page.','mountresort'),
    ),
    array(
      'id'      => 'show-postformat-info',
      'type'    => 'switcher',
      'title'   => esc_html__('Show Post Format Info', 'mountresort' ),
      'default' => true
    ),
    array(
      'id'      => 'show-author-info',
      'type'    => 'switcher',
      'title'   => esc_html__('Show Post Author Info', 'mountresort' ),
      'default' => true,
    ),
    array(
      'id'      => 'show-date-info',
      'type'    => 'switcher',
      'title'   => esc_html__('Show Post Date Info', 'mountresort' ),
      'default' => true
    ),
    array(
      'id'      => 'show-comment-info',
      'type'    => 'switcher',
      'title'   => esc_html__('Show Post Comment Info', 'mountresort' ),
      'default' => true
    ),
    array(
      'id'      => 'show-category-info',
      'type'    => 'switcher',
      'title'   => esc_html__('Show Post Category Info', 'mountresort' ),
      'default' => true
    ),
    array(
      'id'      => 'show-tag-info',
      'type'    => 'switcher',
      'title'   => esc_html__('Show Post Tag Info', 'mountresort' ),
      'default' => true
    )    
  )
);

// -----------------------------------------
// One Page Template Section
// -----------------------------------------
$one_page_template_section = array(
  'name'  => 'one_page_template_section',
  'title' => esc_html__('One Page Template', 'mountresort'),
  'icon'  => 'fa fa-file-o',
  'fields' =>  array(
    array(
      'id'           => 'one-page-tpl-notice',
      'type'         => 'notice',
      'class'        => 'success',
      'content'      => __('One Page Tab Works only if page template set to One Page Template in Page Attributes','mountresort'),
      'class'        => 'margin-30 cs-success',      
    ),
    array(
      'id'            => 'onepage_menu',
      'type'          => 'select',
      'title'         => esc_html__('Menu', 'mountresort' ),
      'options'       => 'categories',
      'query_args'  => array(
        'post_type' => 'nav_menu_item',
        'taxonomy'  => 'nav_menu',
      ),
      'default_option' => __('Select a Menu','mountresort'),
    ),        
  )  
);

// -----------------------------------------
// Portfolio Template Section
// -----------------------------------------
$portfolio_template_section = array(
  'name'  => 'portfolio_template_section',
  'title' => esc_html__('Portfolio Template', 'mountresort'),
  'icon'  => 'fa fa-picture-o',
  'fields' =>  array(

    array(
      'id'           => 'portfolio-tpl-notice',
      'type'         => 'notice',
      'class'        => 'success',
      'content'      => __('Portfolio Tab Works only if page template set to Portfolio Template in Page Attributes','mountresort'),
      'class'        => 'margin-30 cs-success',      
    ),

    array(
      'id'                     => 'portfolio-post-layout',
      'type'                   => 'image_select',
      'title'                  => esc_html__('Post Layout', 'mountresort' ),
      'options'                => array(
          'one-half-column'    => MOUNT_RESORT_THEME_URI . '/cs-framework-override/images/one-half-column.png',
          'one-third-column'   => MOUNT_RESORT_THEME_URI . '/cs-framework-override/images/one-third-column.png',
          'one-fourth-column'   => MOUNT_RESORT_THEME_URI . '/cs-framework-override/images/one-fourth-column.png',
      ),
      'default'                => 'one-half-column'
    ),

    array(
      'id'      => 'portfolio-post-style',
      'type'    => 'select',
      'title'   => esc_html__('Post Style', 'mountresort' ),
      'options' => array(
        'type1' => esc_html__('Modern Title','mountresort'),
        'type2' => esc_html__('Title & Icons Overlay','mountresort'),
        'type3' => esc_html__('Title Overlay','mountresort'),
        'type4' => esc_html__('Icons Only','mountresort'),
        'type5' => esc_html__('Classic','mountresort'),
        'type6' => esc_html__('Minimal Icons','mountresort'),
        'type7' => esc_html__('Presentation','mountresort'),
        'type8' => esc_html__('Girly','mountresort'),
        'type9' => esc_html__('Art','mountresort'),
      ),
    ),

    array(
      'id'      => 'portfolio-grid-space',
      'type'    => 'switcher',
      'title'   => esc_html__('Allow Grid Space', 'mountresort' ),
      'default' => true,
      'info'    => esc_html__('YES! to allow grid space in between portfolio item','mountresort')
    ),

    array(
      'id'      => 'filter',
      'type'    => 'switcher',
      'title'   => esc_html__('Allow Filters', 'mountresort' ),
      'default' => true,
      'info'    => esc_html__('YES! to allow filter options for portfolio items','mountresort')
    ),

    array(
      'id'           => 'portfolio-post-per-page',
      'type'         => 'number',
      'title'        => esc_html__('Post Per Page', 'mountresort' ),
      'default'      => '-1',      
    ),

    array(
      'id'             => 'portfolio-categories',
      'type'           => 'select',
      'title'          => esc_html__('Categories','mountresort'),
      'options'        => 'categories',
      'class'          => 'chosen',
      'query_args'     => array(
        'type'         => 'dt_portfolios',
        'taxonomy'     => 'portfolio_entries',
        'orderby'      => 'post_date',
        'order'        => 'DESC',
      ),
      'attributes'         => array(
        'data-placeholder' => esc_html__('Select a categories','mountresort'),
        'multiple'         => 'only-key',
        'style'            => 'width: 200px;'
      ),
      'info'           => esc_html__('Select categories to show in portfolio items.','mountresort'),
    ),   
  )
);

// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// METABOX OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options = array();

// -----------------------------------------
// Page Metabox Options                    -
// -----------------------------------------
$options[] = array(
  'id'        => '_dt_page_settings',
    'title'     => esc_html__('Page Settings','mountresort'),
    'post_type' => 'page',
    'context'   => 'normal',
    'priority'  => 'high',
    'sections'  => array(
    $meta_layout_section,
    $meta_breadcrumb_section,
    $meta_slider_section,
    
    $blog_template_section,
    $one_page_template_section,
    $portfolio_template_section
    )
);

// -----------------------------------------
// Post Metabox Options                    -
// -----------------------------------------
$post_meta_layout_section = $meta_layout_section;
$fields = $post_meta_layout_section['fields'];

  $fields[0]['title'] =  esc_html__('Post Layout', 'mountresort' );
  unset( $fields[0]['options']['with-both-sidebar'] );
  unset( $fields[0]['options']['fullwidth'] );
  unset( $post_meta_layout_section['fields'] );
  $post_meta_layout_section['fields']  = $fields;  
  
  $post_format_section = array(
    'name'  => 'post_format_data_section',
    'title' => esc_html__('Post Format', 'mountresort'),
    'icon'  => 'fa fa-cog',
    'fields' =>  array(
      
      array(
        'id' => 'post-format-type',
        'title'   => esc_html__('Type', 'mountresort' ),
        'type' => 'select',
        'default' => 'standard',
        'options' => array(
          'standard'  => esc_html__('Standard', 'mountresort'),
          'status'  => esc_html__('Status','mountresort'),
          'quote'   => esc_html__('Quote','mountresort'),
          'gallery' => esc_html__('Gallery','mountresort'),
          'image'   => esc_html__('Image','mountresort'),
          'video'   => esc_html__('Video','mountresort'),
          'audio'   => esc_html__('Audio','mountresort'),
          'link'    => esc_html__('Link','mountresort'),
          'aside'   => esc_html__('Aside','mountresort'),
          'chat'    => esc_html__('Chat','mountresort')
        )
      ),
          
      array(
        'id'      => 'show-featured-image',
        'type'    => 'switcher',
        'title'   => esc_html__('Show Featured Image', 'mountresort' ),
        'default' => true,
        'info'    => esc_html__('YES! to show featured image','mountresort')
      ),
      
      array(
        'id'    => 'post-gallery-items',
        'type'    => 'gallery',
        'title'   => esc_html__('Add Images', 'mountresort' ),
        'add_title'   => esc_html__('Add Images', 'mountresort' ),
        'edit_title'  => esc_html__('Edit Images', 'mountresort' ),
        'clear_title' => esc_html__('Remove Images', 'mountresort' ),
        'dependency' => array( 'post-format-type', '==', 'gallery' ),
      ),
      
      array(
        'id'    => 'audio-or-video-post',
        'type'    => 'select',
        'title'   => esc_html__('Select Type', 'mountresort' ),
        'dependency' => array( 'post-format-type', 'any', 'video,audio' ),
            'options' => array(
          'oembed' => esc_html__('Oembed','mountresort'),
          'self' => esc_html__('Self Hosted','mountresort'),
        )
      ),
      
      array(
        'id'    => 'media-url',
        'type'    => 'textarea',
        'title'   => esc_html__('Media URL', 'mountresort' ),
        'dependency' => array( 'post-format-type', 'any', 'video,audio' ),
      ),
    )
  );
  
  $options[] = array(
    'id'        => '_dt_post_settings',
    'title'     => esc_html__('Post Settings','mountresort'),
    'post_type' => 'post',
    'context'   => 'normal',
    'priority'  => 'high',
    'sections'  => array(
      $post_meta_layout_section,
      $meta_breadcrumb_section,
      $post_format_section      
    )
  );

// -----------------------------------------
// Tribe Events Post Metabox Options
// -----------------------------------------
  array_push( $post_meta_layout_section['fields'], array(
    'id' => 'event-post-style',
    'title'   => esc_html__('Post Style', 'mountresort' ),
    'type' => 'select',
    'default' => 'type1',
    'options' => array(
      'type1'  => esc_html__('Classic', 'mountresort'),
      'type2'  => esc_html__('Full Width','mountresort'),
      'type3'  => esc_html__('Minimal Tab','mountresort'),
      'type4'  => esc_html__('Clean','mountresort'),
      'type5'  => esc_html__('Modern','mountresort'),
    )
  ) );

  $options[] = array(
    'id'        => '_custom_settings',
    'title'     => esc_html__('Settings','mountresort'),
    'post_type' => 'tribe_events',
    'context'   => 'normal',
    'priority'  => 'high',
    'sections'  => array(
      $post_meta_layout_section,
      $meta_breadcrumb_section
    )
  );
    
CSFramework_Metabox::instance( $options );